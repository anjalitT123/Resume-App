import React, { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Offcanvas from 'react-bootstrap/Offcanvas';

const Projects = ({handleSubmit, userInput, handleChange, ProjectRemoveHandler, toDoList}) => {

    return (
        <>
        {[false].map((expand) => (
          <Navbar key={expand} expand={expand}>
          
              
              
              {/* <Navbar.Toggle><h2>Info</h2> </Navbar.Toggle> 
              <Navbar.Toggle><h2>Social</h2> </Navbar.Toggle>  */}
              <Navbar.Toggle><h2>Projects</h2> </Navbar.Toggle> 
              <Navbar.Offcanvas
                id={`offcanvasNavbar-expand-${expand}`}
                aria-labelledby={`offcanvasNavbarLabel-expand-${expand}`}
               
              >
                <Offcanvas.Header closeButton>
                  <Offcanvas.Title id={`offcanvasNavbarLabel-expand-${expand}`}>
                    Projects Lists
                  </Offcanvas.Title>
                </Offcanvas.Header>
                <Offcanvas.Body>
                  <Nav className="justify-content-end flex-grow-1 pe-3">
                    {/* <NavDropdown
                      title="Degree"
                      id={`offcanvasNavbarDropdown-expand-${expand}`}
                    > */}
                      {/* <NavDropdown
                       title="Masters"
                       
                      > */}
                    <form onSubmit={handleSubmit}>
                        <input className='form-control'  name="task" type="text" onChange={handleChange} placeholder="Add Project list here..."/>
                        <button>Submit</button>
                    </form>
                    <div>
            {toDoList?.map((item, index)=>{
            return(
                <li>
                    {/* {index} */}
                <p>{item.task}</p> 
                    <Button  variant="outline-success" onClick={ProjectRemoveHandler}>remove</Button>
                </li>
            )
            })}
        </div>
        {/* </NavDropdown> */}
                  {/* </NavDropdown> */}
                </Nav>
                {/* <Form className="d-flex">
                  <Form.Control
                    type="text"
                   
                    className="me-2"
                    aria-label="Search"
                  />
                  <button variant="outline-success">Add</button>
                </Form> */}
              </Offcanvas.Body>
            </Navbar.Offcanvas>
       
        </Navbar>
      ))}
        </>
    );
};

export default Projects;
