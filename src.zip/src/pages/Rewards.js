import React, { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Offcanvas from 'react-bootstrap/Offcanvas';

const Rewards = ({handleRewardSubmit, inputReward, handleChangeReward, RewardRemoveHandler, rewardList}) => {

    return (
        <>
        {[false].map((expand) => (
          <Navbar key={expand} expand={expand}>
          
              
              
              {/* <Navbar.Toggle><h2>Info</h2> </Navbar.Toggle> 
              <Navbar.Toggle><h2>Social</h2> </Navbar.Toggle>  */}
              <Navbar.Toggle><h2>Rewards</h2> </Navbar.Toggle> 
              <Navbar.Offcanvas
                id={`offcanvasNavbar-expand-${expand}`}
                aria-labelledby={`offcanvasNavbarLabel-expand-${expand}`}
               
              >
                <Offcanvas.Header closeButton>
                  <Offcanvas.Title id={`offcanvasNavbarLabel-expand-${expand}`}>
                    Certificate and Rewards
                  </Offcanvas.Title>
                </Offcanvas.Header>
                <Offcanvas.Body>
                  <Nav className="justify-content-end flex-grow-1 pe-3">
                    {/* <NavDropdown
                      title="Degree"
                      id={`offcanvasNavbarDropdown-expand-${expand}`}
                    > */}
                      {/* <NavDropdown
                       title="Masters"
                       
                      > */}
                    <form onSubmit={handleRewardSubmit}>
                        <input  name="certificate" type="text" value={inputReward} onChange={handleChangeReward} placeholder="Add Reward list here..."/>
                        <button>Submit</button>
                    </form>
                    <div>
            {rewardList?.map((item, i)=>{
            return(
                <li key={i}>
                    {/* {index} */}
                <p>{item.certificate}
                    <Button  variant="outline-success" onClick={RewardRemoveHandler}>remove</Button></p> 
                </li>
            )
            })}
        </div>
        {/* </NavDropdown> */}
                  {/* </NavDropdown> */}
                </Nav>
                {/* <Form className="d-flex">
                  <Form.Control
                    type="text"
                   
                    className="me-2"
                    aria-label="Search"
                  />
                  <button variant="outline-success">Add</button>
                </Form> */}
              </Offcanvas.Body>
            </Navbar.Offcanvas>
       
        </Navbar>
      ))}
        </>
    );
};

export default Rewards;

