import React, { useState } from 'react';
import Form from 'react-bootstrap/Form';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Offcanvas from 'react-bootstrap/Offcanvas';
import Resume from './Resume';

const Social = ({changeState, instagram, behance, github, facebook, linkedin}) => {
    return (
        <>
          {[false].map((expand) => (
            <Navbar key={expand} expand={expand}>
                <Navbar.Toggle><h2>Social</h2> </Navbar.Toggle> 
        <Navbar.Offcanvas
                  id={`offcanvasNavbar-expand-${expand}`}
                  aria-labelledby={`offcanvasNavbarLabel-expand-${expand}`}
                 
                >
                  <Offcanvas.Header closeButton>

                    <Offcanvas.Title id={`offcanvasNavbarLabel-expand-${expand}`}>
                      Social
                    </Offcanvas.Title>
                  </Offcanvas.Header>
                  <Offcanvas.Body>
                    <Nav className="justify-content-end flex-grow-1 pe-3">
                      <Nav.Link href="#action1">Linkedin</Nav.Link>
                      </Nav>
                    <Form className="d-flex" >
                 
                      <Form.Control
                      target="_blank"
                        type="search"
                        className="me-2"
                        name='linkedin'
                        value={linkedin}
                        onChange={changeState}
                       
                      />
                    
                    </Form>
                    <Nav className="justify-content-end flex-grow-1 pe-3">
                      <Nav.Link href="#action1">Github</Nav.Link>
                      </Nav>
                    <Form className="d-flex">
                      <Form.Control
                        type="search"
                        className="me-2"
                        name='github'
                        value={github}
                        onChange={changeState}
                      />
                    
                    </Form>
                    <Nav className="justify-content-end flex-grow-1 pe-3">
                      <Nav.Link href="#action1">Facebook</Nav.Link>
                      </Nav>
                    <Form className="d-flex">
                      <Form.Control
                        type="search"
                        className="me-2"
                        name='facebook'
                        value={facebook}
                        onChange={changeState}
                      />
                    
                    </Form>
                    <Nav className="justify-content-end flex-grow-1 pe-3">
                      <Nav.Link href="#action1">Behance</Nav.Link>
                      </Nav>
                    <Form className="d-flex">
                      <Form.Control
                        type="search"
                        className="me-2"
                        name='behance'
                        value={behance}
                        onChange={changeState}
                      />
                    </Form>
                    <Nav className="justify-content-end flex-grow-1 pe-3">
                      <Nav.Link href="#action1">Instagram</Nav.Link>
                      </Nav>
                    <Form className="d-flex">
                      <Form.Control
                        type="search"
                        className="me-2"
                        name='instagram'
                        value={instagram}
                        onChange={changeState}
                      />
                 
                    </Form>
                  </Offcanvas.Body>
                </Navbar.Offcanvas>
           
            </Navbar>
          ))}
          <Resume />
        </>
      );
    }

export default Social;