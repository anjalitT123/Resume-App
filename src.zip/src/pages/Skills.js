import React, { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Offcanvas from 'react-bootstrap/Offcanvas';
import Resume from './Resume';
import SkillExposure from './SkillExposure';
import Methodology from './Methodology';

const Skills = ({setInputList, changeState, removeHandler, handleAdd, inputList, skills, SkillRemoveHandler, handleAddExposure,setmethododlogy, techskills,handleAddMethodology, MethodologyRemoveHandler, methododlogy,addInputSkill,
  removeInputSkill,
  inputSkill,
   setInputSkill}) => {
   

    const handleChange = (index, evnt)=>{
  
      const { name, value } = evnt.target;
      const list = [...inputList];
      list[index][name] = value;
      setInputList(list);
     
      
      
      
      }

  return (
    <>
      {[false].map((expand) => (
        <Navbar key={expand} expand={expand} className="mb-3">
            <Navbar.Toggle><h2>Skills</h2> </Navbar.Toggle> 
          
            <Navbar.Offcanvas
              id={`offcanvasNavbar-expand-${expand}`}
              aria-labelledby={`offcanvasNavbarLabel-expand-${expand}`}
             
            >
              <Offcanvas.Header closeButton>
                <Offcanvas.Title id={`offcanvasNavbarLabel-expand-${expand}`}>
                 Technical Skill
                </Offcanvas.Title>
              </Offcanvas.Header>
             
              <Offcanvas.Body>
                <Nav className="justify-content-end flex-grow-1 pe-3">
                  {/* <Nav.Link href="#action1">Technical Expertise</Nav.Link> */}
                 
                </Nav>
                {inputList?.map((name, index) => {
               return (
                <Form key={index} className="d-flex">
                  <Form.Control
                
                    type="text"
                    placeholder="Add tech skills"
                    className="me-2"
                    name='techskills'
                    value={name.techskills}
                 //  value={inputList}
                    onChange={(evnt)=>handleChange(index, evnt)} 
                  />
                    
                     <Button variant="outline-success" onClick={removeHandler}>remove</Button>
                     {/* <ul>
                     <li  key={index}
                     index={index}>
                {name?.techskills}</li></ul> */}
                </Form>
                );
              })}
                <Button variant="outline-success" onClick={handleAdd}>Add Technical Expertise</Button>
                <h5>Skill Exposure</h5>
                <div className="d-flex ">
                  
     <SkillExposure 
     addInputSkill={addInputSkill}
     removeInputSkill={removeInputSkill}
     inputSkill={inputSkill}
      setInputSkill={setInputSkill}
     />
     </div>
     <h5>Skill Methodology</h5>
     <div className="d-flex">
    < Methodology 
     methododlogy={methododlogy}
     setmethododlogy={setmethododlogy}
     MethodologyRemoveHandler={MethodologyRemoveHandler}
     handleAddMethodology={handleAddMethodology}
     changeState={changeState}
    />
    </div> 
              </Offcanvas.Body>
            
            </Navbar.Offcanvas>
     
        </Navbar>
        
      ))}
    </>
     
  );
}

 
export default Skills;