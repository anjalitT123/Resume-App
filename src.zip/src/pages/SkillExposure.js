import React, { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Offcanvas from 'react-bootstrap/Offcanvas';
import Resume from './Resume';

const SkillExposure = ({ addInputSkill,
  removeInputSkill,
  inputSkill,
   setInputSkill}) => {
    
  const handleChange = (index, evnt)=>{
  
    const { name, value } = evnt.target;
    const list = [...inputSkill];
    list[index][name] = value;
    setInputSkill(list);
    
    
    
    }


        return (
    <>
   {[false].map((expand) => (
        <Navbar key={expand}  className="mb-3">
            {/* <Navbar.Toggle><h2>Skills</h2> </Navbar.Toggle>  */}
          
            <Navbar.Offcanvas
              id={`offcanvasNavbar-expand-${expand}`}
              aria-labelledby={`offcanvasNavbarLabel-expand-${expand}`}
             
            >
              <Offcanvas.Header closeButton>
                <Offcanvas.Title id={`offcanvasNavbarLabel-expand-${expand}`}>
                Skill Exposure
                </Offcanvas.Title>
              </Offcanvas.Header>
             
              
                <Nav>
                  <Nav.Link href="#action1">Technical Expertise</Nav.Link>
                 
                </Nav>
                {inputSkill?.map((name, index) => {
               return (
                <Form key={index} className="d-flex">
                
                   <Form.Control
               className="me-2"
              
                type="text" onChange={(evnt)=>handleChange(index, evnt)}  name="skillExposure"   value={name?.skillExposure} placeholder="skillExposure"
                  />
                     <Button variant="outline-success" onClick={(index)=>removeInputSkill(index)}>remove</Button>
                     {/* <ul>
                     <li  key={index}
                     index={index}>
                {name?.techskills}</li></ul> */}
                </Form>
                );
              })}
               
             
              <Button name='skillExposure' variant="outline-success" onClick={addInputSkill}>Add skillExposure</Button>
            </Navbar.Offcanvas>
     
        </Navbar>
          ))}
     
    </>
  );
}

 
export default SkillExposure;
  
