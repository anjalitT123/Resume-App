import React, { useEffect, useState } from 'react';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Offcanvas from 'react-bootstrap/Offcanvas';
import Info from './pages/Info';
import Skills from './pages/Skills';
import Social from './pages/Social';
import Experince from './pages/Experience';
import Education from './pages/Education';
import Resume from './pages/Resume';
import Projects from './pages/Projects';
import Rewards from './pages/Rewards';


const Sidebar = () => {
  const [username, setUsername] = useState({
    name:"John",
    image:"",
    role:"Front End Developer",
    email:"janedoe@email.com",
    phone:"91 9876543210",
    location:"Benglauru",
    relevantexperience:" 4 ",
    totalexperince:" 6", 
    summary:"I am a web developer having expertise in frontend development and exposure to back- end development. I design and develop web applications using the latest technologies to deliver the product with quality code.",
    objective:"Eager to expand my skill set through external trainings to help boost all major front desk KPIs. Hoping to leverage organizational skills to help ABC Corp introduce time-saving schemes for all executives.",
    linkedin:"https://linkedin.com/",
    facebook:"https://facebook.com",
    github:"https://github.com",
    behance:"https://www.behance.net",
    instagram:"https://instagram.com/",
    // Education..........
    masters:"MS",
    Mstream:"Cloud technology",
    Muniversity:"MIT, University",
    Myear:"2014-2016",
    Mscore:"68",
    graduate:"Btech",
    stream:"Computer Science",
    university:"NMAMIT, Nitte",
    year:"2010-2014",
    score:"2.3",
   // skills
    techskills:[],
    skillExposure:[],
    skills:[],
    methododlogy:[],
  //Projects..
  toDoList:[],
  //Rewads...
  rewardList:[],
   //Add company sections..
  inputFields:[],
  inputSkill:[],
  inputList:[]


  });
  // const [username, setUsername] = useState(()=>{
  //   const savedItem = localStorage.getItem("username");
  //   if (savedItem) {
  //     return JSON.parse(savedItem);
  //   } else {
  //     return [];
      
  //   }
  // });
  
  const changeState = (e, index) => {
    const value = [e.target.value];
    setUsername({
      ...username,
      [(e.target.name)]: value
    });
    
  }
////Experince .......................................................
    const [inputFields, setInputFields] = useState([{
     companyName:'Company1',
      designation:'Senior react js developer',
      jobroles:'Use my extensive experience with front end development to define the structure and components for the project, making sure they are reusable'  
  } ]);
  
  const addInputField = ()=>{
  
      setInputFields([...inputFields, {
        companyName:'',
        designation:'',
        jobroles:''  
      } ]);
    
  }
  const removeInputFields = (index)=>{
      const lists = [...inputFields];
      lists.splice(index, 1);
      setInputFields(lists);
  }
  const handleChangee = (index, evnt)=>{
  
  const { name, value } = evnt.target;
  const list = [...inputFields];
  list[index][name] = value;
  setInputFields(list);
  
  
  
  }
  //skillss exposure......................................
  const [inputSkill, setInputSkill] = useState([{
    skillExposure:'Redux'
    } ]);
 
 const addInputSkill = ()=>{
 
  setInputSkill([...inputSkill, {
    skillExposure:'' 
     } ]);
   
 }
 const removeInputSkill = (index)=>{
     const rows = [...inputSkill];
     rows.splice(index, 1);
     setInputSkill(rows);
 }
  //console.log(username);

  ///Tech skillss....................................................................
  const [inputList, setInputList] = useState([{techskills:'javascript'}]);

  const handleAdd=(e)=>{
    setInputList([...inputList,{techskills:''}])
  }
  const removeHandler =(index) => {
    const list= [...inputList];
    list.splice(index,1);
    setInputList(list);
  }


  ///methododlogy..............................................................
      const[methododlogy, setmethododlogy] =  useState([{methododlogy:'Agile methodology'}]);
    const handleAddMethodology=()=>{
      setmethododlogy([...methododlogy,{methododlogy:" "}]);
      }
      // console.log("this is skills array",methododlogy);
      
      const MethodologyRemoveHandler =(index) => {
        const list= [...methododlogy];
        list.splice(index,1);
        setmethododlogy(list);
      }

 // projects...................................................................
       const [ userInput, setUserInput ] = useState('');
       const [ toDoList, setToDoList ] = useState([{task:"Prevented millions of dollars in state sales tax undercharges by initiating tests that revealed a bug in a new release of shopping cart software."}]);
   
       const handleChange = (e) => {
           setUserInput(e.currentTarget.value)
       }
       const addTask = (userInput ) => {
           let copy = [...toDoList];
           copy = [...copy, { id: toDoList.length + 1, task: userInput}];
           setToDoList(copy);
           
         }
        //  console.log("this is my task",toDoList);
       const handleSubmit = (e) => {
           e.preventDefault();
           addTask(userInput);
           setUserInput();
           
       }
       const ProjectRemoveHandler =(index) => {
           const list= [...toDoList];
           list.splice(index,1);
           setToDoList(list);
         }
        //  console.log("this is my task22",userInput);
//Rewards...............................................................................
const [ inputReward, setRewardsInput ] = useState('');
const [ rewardList, setRewardList ] = useState([{certificate:"Best performer award for consistently exceeding the performance."}]);
const handleChangeReward = (e) => {
  setRewardsInput(e.currentTarget.value)
}
const addReward = (inputReward ) => {
  let copy = [...rewardList];
  copy = [...copy, { id: rewardList.length + 1, certificate: inputReward}];
  setRewardList(copy);
}
// console.log("this is my task",rewardList);
const handleRewardSubmit = (e) => {
  e.preventDefault();
  addReward(inputReward);
  setRewardsInput("");
}
const RewardRemoveHandler =(index) => {
  const list= [...rewardList];
  list.splice(index,1);
  setRewardList(list);
}




useEffect(()=>{
  setUsername({
    ...username,
    techskills:[...inputList],
   // skillExposure:[...skills],
    methododlogy:[...methododlogy],
   // company:[...company],
    toDoList:[...toDoList],
    rewardList:[...rewardList],
    inputFields:[...inputFields],
    inputSkill:[...inputSkill],
    inputList:[...inputList]
        })
      },[inputList, methododlogy, toDoList, rewardList, inputFields, inputSkill]);
  return (
    <>

      <div className='container-fluid'>
        <div className="sidenav" >

          <h2>
          <Info
          changeState={changeState}
          userName={username.name}
          userRole={username.role}
          userEmail={username.email}
          userPhone={username.phone}
          userLocation={username.location}
          userRelExp={username.relevantexperience}
          userTotalExp={username.totalexperince}
          userSummary={username.summary}
          userObjective={username.objective}
          />
          </h2>
          <h2> 
          <Social
          changeState={changeState}
          linkedin={username.linkedin}
          facebook={username.facebook}
          github={username.github}
          behance={username.behance}
          instagram={username.instagram}
          
          />
          </h2>
          <h2> <Skills 
          changeState={changeState}
          removeHandler={removeHandler}
          handleAdd={handleAdd}
          inputList={username.inputList}
         // SkillRemoveHandler={SkillRemoveHandler}
         // handleAddExposure={handleAddExposure}
         // skills={username.skillExposure}
          methododlogy={username.methododlogy}
          setmethododlogy={setmethododlogy}
          MethodologyRemoveHandler={MethodologyRemoveHandler}
          handleAddMethodology={handleAddMethodology}
          //setskills={setskills}
          addInputSkill={addInputSkill}
          removeInputSkill={removeInputSkill}
          inputSkill={username.inputSkill}
           setInputSkill={setInputSkill}
           setInputList={setInputList}
   


          /></h2>
          <h2>
         <Experince 
         changeState={changeState}
         handleChangee={handleChangee}
         addInputField={addInputField}
         removeInputFields={removeInputFields}
          inputFields={username.inputFields}
          setInputFields={setInputFields}
          companyName={inputFields.companyName}
          
          // company={username.company}
          // handleSubmitCompany={handleSubmitCompany}
        

            /></h2>
          <h2> 
            <Education
             changeState={changeState}
             masters={username.masters}
             Mstream={username.Mstream}
             Muniversity={username.Muniversity}
             Myear={username.Myear}
             Mscore={username.Mscore}
             graduate={username.graduate}
             stream={username.stream}
             university={username.university}
             year={username.year}
             score={username.score}
             
             />
             </h2>
          <h2>
            <Projects 
            toDoList={username.toDoList}
            handleSubmit={handleSubmit}
            handleChange={handleChange}
            ProjectRemoveHandler={ProjectRemoveHandler}

            />
            </h2>
            <h2>
              <Rewards 
              handleChangeReward={handleChangeReward}
              handleRewardSubmit={handleRewardSubmit}
              RewardRemoveHandler={RewardRemoveHandler}
              rewardList={username.rewardList}


              />
            </h2>
        </div>
        <Resume 
        username={username}
        inputList={inputList}
     
        />
      </div>

    </>
  );
}

export default Sidebar;