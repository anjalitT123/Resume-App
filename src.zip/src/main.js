import React from 'react';
import Sidebar from './sidebar';
import Resume from './pages/Resume';

const main = () => {
  return (
   
<div>
    <Sidebar />
    {/* <Resume /> */}
</div>


  )
}

export default main