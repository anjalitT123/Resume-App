import './App.css';
import Sidebar from './sidebar';
import Main from './main';



function App() {
  return (
    <div className="App">
     <Main />

    </div>
  );
}

export default App;
